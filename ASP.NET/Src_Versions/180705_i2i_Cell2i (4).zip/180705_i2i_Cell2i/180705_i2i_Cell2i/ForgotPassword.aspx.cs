﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _180705_i2i_Cell2i
{
    public partial class ForgotPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_change_Click(object sender, EventArgs e)
        {

        }
        public Boolean isValid(string password)
        {
            return (password.Any(char.IsDigit) && (password.Any(char.IsSymbol) || password.Any(char.IsPunctuation)));
            
        }
    }
}