﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _180705_i2i_Cell2i
{
    public class Customer
    {
        string phoneNumber;
        string password;

    
        public Customer(string phoneNumber,string password)
        {
            this.phoneNumber = phoneNumber;
            this.password = password;
        }

        public void setPhoneNumber(string phoneNumber)
        {
            this.phoneNumber = phoneNumber;
        }


        public string getPhoneNumber()
        {
            return phoneNumber;        
        }

        public void setPassword(string password)
        {
            this.password = password;
        }
        public string getPassword()
        {
            return password;
        }


        public Boolean isAuthenticated()
        {
            try
            {

                Cell2iService.Cell2iWebServiceImplClient client = new Cell2iService.Cell2iWebServiceImplClient();
                if (client.success_statu() == "Connect Successful")
                {
                    if (client.userControl(this.phoneNumber,this.password))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                System.Console.WriteLine(e);
                
                return false;
            }

        }



    }
}