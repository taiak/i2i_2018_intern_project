﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _180705_i2i_Cell2i
{
    public partial class Login : System.Web.UI.Page
    {
        public static string str_phoneNumber = "xxxxxxxxxx";
        public static string str_password = "admin";
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btn_login_Click(object sender, EventArgs e)
        {

            isValid(getPhoneNumberFromTextBox(),getPasswordFromTextBox());
        }
        public Boolean isNotEqual(string pin_str_given, string pin_str_compared)
        {
            if (pin_str_given != pin_str_compared)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void isValid(string str_phoneNumber, string str_password)
        {
            if (isNotEqual(getPhoneNumberFromTextBox(),getPhoneNumberFromWeb())|| isNotEqual(getPasswordFromTextBox(), getPasswordFromWeb()))
            {
                lbl_invalid.Visible = true;
                txt_phoneNumber.BorderColor=System.Drawing.ColorTranslator.FromHtml("#FF0000");
                txt_password.BorderColor = System.Drawing.ColorTranslator.FromHtml("#FF0000");
            }
            else
            {
                Page.Response.Redirect("Info.aspx");         
            }
        }
        public string getPhoneNumberFromTextBox()
        {
            return txt_phoneNumber.Text;
        }
        public string getPasswordFromTextBox()
        {
            return txt_password.Text;
        }

        public string getPhoneNumberFromWeb() //to do,to do, to do, to do, to do, to do, to doo....
        {
            return str_phoneNumber;
        }
        public string getPasswordFromWeb() //to do,to do, to do, to do, to do, to do, to doo....
        {
            return str_password;
        }
    }
}